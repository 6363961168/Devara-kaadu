package com.devara.kaadu.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Yard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devara.kaadu.data.HardcodedData
import com.devara.kaadu.data.db.ConservationAlert
import com.devara.kaadu.ui.theme.*
import com.devara.kaadu.ui.viewmodel.AppViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConservationAlertScreen(viewModel: AppViewModel) {
    val allAlerts by viewModel.allAlerts.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val groveNames = HardcodedData.groves.map { it.nameEnglish }
    val threatTypes = listOf(
        "Waste Dumping",
        "Tree Cutting",
        "Encroachment",
        "Poaching",
        "Other"
    )

    var selectedGrove by remember { mutableStateOf(groveNames.first()) }
    var selectedThreat by remember { mutableStateOf(threatTypes.first()) }
    var description by remember { mutableStateOf("") }

    var groveDropdownExpanded by remember { mutableStateOf(false) }
    var threatDropdownExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Yard,
                            contentDescription = "Leaf",
                            tint = AccentGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Report a Threat",
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = Parchment
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Parchment
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Form Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PaleLeafGreen),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Alert Form",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = BarkBrown
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Grove Dropdown
                    Text(
                        text = "Select Grove",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = BarkBrown
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    ExposedDropdownMenuBox(
                        expanded = groveDropdownExpanded,
                        onExpandedChange = { groveDropdownExpanded = !groveDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedGrove,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = groveDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            shape = RoundedCornerShape(10.dp),
                            textStyle = LocalTextStyle.current.copy(
                                fontFamily = FontFamily.Serif,
                                fontSize = 14.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryGreen,
                                unfocusedBorderColor = PrimaryGreen.copy(alpha = 0.4f)
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = groveDropdownExpanded,
                            onDismissRequest = { groveDropdownExpanded = false }
                        ) {
                            groveNames.forEach { name ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = name,
                                            fontFamily = FontFamily.Serif,
                                            fontSize = 14.sp
                                        )
                                    },
                                    onClick = {
                                        selectedGrove = name
                                        groveDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Threat Type Dropdown
                    Text(
                        text = "Threat Type",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = BarkBrown
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    ExposedDropdownMenuBox(
                        expanded = threatDropdownExpanded,
                        onExpandedChange = { threatDropdownExpanded = !threatDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedThreat,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = threatDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            shape = RoundedCornerShape(10.dp),
                            textStyle = LocalTextStyle.current.copy(
                                fontFamily = FontFamily.Serif,
                                fontSize = 14.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryGreen,
                                unfocusedBorderColor = PrimaryGreen.copy(alpha = 0.4f)
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = threatDropdownExpanded,
                            onDismissRequest = { threatDropdownExpanded = false }
                        ) {
                            threatTypes.forEach { threat ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = threat,
                                            fontFamily = FontFamily.Serif,
                                            fontSize = 14.sp
                                        )
                                    },
                                    onClick = {
                                        selectedThreat = threat
                                        threatDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Description
                    Text(
                        text = "Description",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = BarkBrown
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        placeholder = {
                            Text(
                                text = "Describe what you observed...",
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                fontSize = 13.sp
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        textStyle = LocalTextStyle.current.copy(
                            fontFamily = FontFamily.Serif,
                            fontSize = 14.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryGreen,
                            unfocusedBorderColor = PrimaryGreen.copy(alpha = 0.4f)
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // GPS Field
                    Text(
                        text = "GPS Coordinates (auto-filled)",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = BarkBrown
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = "Lat: ${viewModel.mockLatitude}, Lon: ${viewModel.mockLongitude}",
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        textStyle = LocalTextStyle.current.copy(
                            fontFamily = FontFamily.Serif,
                            fontSize = 13.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryGreen.copy(alpha = 0.3f),
                            unfocusedBorderColor = PrimaryGreen.copy(alpha = 0.2f),
                            disabledTextColor = BarkBrown.copy(alpha = 0.6f)
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (description.isNotBlank()) {
                                viewModel.submitAlert(selectedGrove, selectedThreat, description)
                                description = ""
                                scope.launch {
                                    snackbarHostState.showSnackbar("Alert recorded. Thank you, Guardian!")
                                }
                            } else {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Please add a description.")
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = "Alert",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Submit Alert",
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Recent Alerts
            Text(
                text = "Recent Alerts",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = BarkBrown
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (allAlerts.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PaleLeafGreen)
                ) {
                    Text(
                        text = "No alerts submitted yet. Be the first guardian.",
                        modifier = Modifier.padding(16.dp),
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        fontSize = 14.sp,
                        color = BarkBrown.copy(alpha = 0.6f)
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    allAlerts.forEach { alert ->
                        AlertCard(alert = alert)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun AlertCard(alert: ConservationAlert) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    val formattedDate = dateFormat.format(Date(alert.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Parchment),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = alert.groveName,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = BarkBrown
                    )
                    Text(
                        text = alert.threatType,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = DangerRed
                    )
                }
                Text(
                    text = formattedDate,
                    fontFamily = FontFamily.Serif,
                    fontSize = 10.sp,
                    color = BarkBrown.copy(alpha = 0.5f)
                )
            }
            if (alert.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = alert.description,
                    fontFamily = FontFamily.Serif,
                    fontSize = 12.sp,
                    color = BarkBrown.copy(alpha = 0.7f)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "📍 ${alert.latitude}, ${alert.longitude}",
                fontFamily = FontFamily.Serif,
                fontSize = 10.sp,
                color = BarkBrown.copy(alpha = 0.5f)
            )
        }
    }
}
