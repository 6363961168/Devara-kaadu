package com.devara.kaadu.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "species_sightings")
data class SpeciesSighting(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val speciesName: String,
    val groveName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
