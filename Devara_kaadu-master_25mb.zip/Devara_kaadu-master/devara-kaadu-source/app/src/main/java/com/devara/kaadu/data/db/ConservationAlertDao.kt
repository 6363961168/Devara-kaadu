package com.devara.kaadu.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ConservationAlertDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(alert: ConservationAlert)

    @Query("SELECT * FROM conservation_alerts ORDER BY timestamp DESC")
    fun getAll(): Flow<List<ConservationAlert>>
}
