package com.devara.kaadu.data.repository

import com.devara.kaadu.data.db.AppDatabase
import com.devara.kaadu.data.db.ConservationAlert
import com.devara.kaadu.data.db.SpeciesSighting
import kotlinx.coroutines.flow.Flow

class AppRepository(private val db: AppDatabase) {

    val allSightings: Flow<List<SpeciesSighting>> = db.speciesSightingDao().getAll()
    val allAlerts: Flow<List<ConservationAlert>> = db.conservationAlertDao().getAll()

    suspend fun addSighting(sighting: SpeciesSighting) {
        db.speciesSightingDao().insert(sighting)
    }

    suspend fun addAlert(alert: ConservationAlert) {
        db.conservationAlertDao().insert(alert)
    }

    fun sightingsByGrove(groveName: String): Flow<List<SpeciesSighting>> {
        return db.speciesSightingDao().getByGrove(groveName)
    }
}
