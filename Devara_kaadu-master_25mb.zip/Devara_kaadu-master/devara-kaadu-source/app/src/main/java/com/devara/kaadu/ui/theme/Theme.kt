package com.devara.kaadu.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = PrimaryGreen,
    onPrimary = Parchment,
    primaryContainer = PaleLeafGreen,
    onPrimaryContainer = BarkBrown,
    secondary = AccentGold,
    onSecondary = BarkBrown,
    secondaryContainer = LightGold,
    onSecondaryContainer = BarkBrown,
    background = Parchment,
    onBackground = BarkBrown,
    surface = Parchment,
    onSurface = BarkBrown,
    surfaceVariant = PaleLeafGreen,
    onSurfaceVariant = BarkBrown,
    error = DangerRed,
    onError = Parchment
)

@Composable
fun DevaraKaaduTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
