package com.devara.kaadu.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [SpeciesSighting::class, ConservationAlert::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun speciesSightingDao(): SpeciesSightingDao
    abstract fun conservationAlertDao(): ConservationAlertDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "devara_kaadu_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
