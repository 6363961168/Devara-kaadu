package com.devara.kaadu.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Yard
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devara.kaadu.data.HardcodedData
import com.devara.kaadu.data.Species
import com.devara.kaadu.ui.theme.*
import com.devara.kaadu.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroveDetailScreen(groveId: Int, viewModel: AppViewModel, onBack: () -> Unit) {
    val grove = HardcodedData.groves.find { it.id == groveId } ?: return
    val isNear = viewModel.isNearGrove(grove)
    val groveSpecies = HardcodedData.species.filter { it.id in grove.speciesFoundIds }

    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Yard,
                            contentDescription = "Leaf",
                            tint = AccentGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = grove.nameEnglish,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = Parchment,
                            fontSize = 16.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Parchment
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        },
        containerColor = Parchment
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // GPS Proximity Banner
            if (isNear) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AccentGold)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🌿 You are near this grove!",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BarkBrown
                    )
                }
            }

            // Grove Header Info
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = grove.nameKannada,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = PrimaryGreen
                )
                Text(
                    text = grove.nameEnglish,
                    fontFamily = FontFamily.Serif,
                    fontSize = 16.sp,
                    color = BarkBrown
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🪔", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = grove.deity,
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        fontSize = 14.sp,
                        color = AccentGold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "• ${grove.district}",
                        fontFamily = FontFamily.Serif,
                        fontSize = 14.sp,
                        color = BarkBrown.copy(alpha = 0.7f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = PaleLeafGreen,
                    contentColor = PrimaryGreen,
                    indicator = { tabPositions ->
                        TabRowDefaults.Indicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = AccentGold,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                "🪔 Divine Legend",
                                fontFamily = FontFamily.Serif,
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                "🔬 Scientific Facts",
                                fontFamily = FontFamily.Serif,
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                when (selectedTab) {
                    0 -> DivineLegendTab(legend = grove.legend)
                    1 -> ScientificFactsTab(grove = com.devara.kaadu.data.Grove(
                        id = grove.id,
                        nameKannada = grove.nameKannada,
                        nameEnglish = grove.nameEnglish,
                        groveType = grove.groveType,
                        district = grove.district,
                        deity = grove.deity,
                        tagline = grove.tagline,
                        latitude = grove.latitude,
                        longitude = grove.longitude,
                        legend = grove.legend,
                        speciesCount = grove.speciesCount,
                        endemicPlants = grove.endemicPlants,
                        waterBodies = grove.waterBodies,
                        climateRole = grove.climateRole,
                        speciesFoundIds = grove.speciesFoundIds
                    ))
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Species Found Here
                Text(
                    text = "Species Found Here",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = BarkBrown
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(groveSpecies) { species ->
                        SpeciesChipCard(species = species)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun DivineLegendTab(legend: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFFFF8E7))
            .border(2.dp, AccentGold.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(20.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🪔", fontSize = 20.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Divine Legend",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = AccentGold
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = legend,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontSize = 15.sp,
                color = BarkBrown,
                lineHeight = 26.sp
            )
        }
    }
}

@Composable
private fun ScientificFactsTab(grove: com.devara.kaadu.data.Grove) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(PaleLeafGreen)
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "🔬", fontSize = 20.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Scientific Facts",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PrimaryGreen
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BioStatCard(modifier = Modifier.weight(1f), value = "${grove.speciesCount}", label = "Total Species")
            BioStatCard(modifier = Modifier.weight(1f), value = "${grove.endemicPlants}", label = "Endemic Plants")
            BioStatCard(modifier = Modifier.weight(1f), value = "${grove.waterBodies}", label = "Water Bodies")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "🔬 Climate Role",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = DeepGreen
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = grove.climateRole,
            fontFamily = FontFamily.Serif,
            fontSize = 14.sp,
            color = BarkBrown,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun BioStatCard(modifier: Modifier = Modifier, value: String, label: String) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PrimaryGreen)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = AccentGold
            )
            Text(
                text = label,
                fontFamily = FontFamily.Serif,
                fontSize = 10.sp,
                color = Parchment.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
private fun SpeciesChipCard(species: Species) {
    val statusColor = when (species.conservationStatus) {
        "Endangered" -> EndangeredRed
        "Vulnerable" -> VulnerableOrange
        else -> LeastConcernGreen
    }

    Card(
        modifier = Modifier.width(160.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Parchment),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = species.commonName,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = BarkBrown
            )
            Text(
                text = species.kannadaName,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontSize = 11.sp,
                color = PrimaryGreen
            )
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .background(statusColor, RoundedCornerShape(20.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = species.conservationStatus,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
