package com.devara.kaadu.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Forest
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.devara.kaadu.ui.screens.ConservationAlertScreen
import com.devara.kaadu.ui.screens.GroveDetailScreen
import com.devara.kaadu.ui.screens.GroveDirectoryScreen
import com.devara.kaadu.ui.screens.HomeScreen
import com.devara.kaadu.ui.screens.MythLegendScreen
import com.devara.kaadu.ui.screens.SpeciesScanScreen
import com.devara.kaadu.ui.theme.AccentGold
import com.devara.kaadu.ui.theme.BarkBrown
import com.devara.kaadu.ui.theme.PaleLeafGreen
import com.devara.kaadu.ui.theme.Parchment
import com.devara.kaadu.ui.theme.PrimaryGreen
import com.devara.kaadu.ui.viewmodel.AppViewModel

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Home)
    object Groves : Screen("groves", "Groves", Icons.Filled.Forest)
    object Scan : Screen("scan", "Scan", Icons.Filled.Eco)
    object Legends : Screen("legends", "Legends", Icons.Filled.MenuBook)
    object Alert : Screen("alert", "Alert", Icons.Filled.Warning)
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.Groves,
    Screen.Scan,
    Screen.Legends,
    Screen.Alert
)

@Composable
fun DevaraKaaduNavGraph() {
    val navController = rememberNavController()
    val viewModel: AppViewModel = viewModel()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showBottomBar = bottomNavItems.any { it.route == currentRoute }

    Scaffold(
        containerColor = Parchment,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = PaleLeafGreen,
                    contentColor = PrimaryGreen
                ) {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(Screen.Home.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = screen.label
                                )
                            },
                            label = {
                                Text(
                                    text = screen.label,
                                    fontFamily = FontFamily.Serif,
                                    fontSize = 10.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryGreen,
                                selectedTextColor = PrimaryGreen,
                                indicatorColor = AccentGold.copy(alpha = 0.3f),
                                unselectedIconColor = BarkBrown.copy(alpha = 0.6f),
                                unselectedTextColor = BarkBrown.copy(alpha = 0.6f)
                            )
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onExploreGroves = { navController.navigate(Screen.Groves.route) },
                    onScanSpecies = { navController.navigate(Screen.Scan.route) }
                )
            }
            composable(Screen.Groves.route) {
                GroveDirectoryScreen(
                    onGroveClick = { groveId ->
                        navController.navigate("grove_detail/$groveId")
                    }
                )
            }
            composable(
                route = "grove_detail/{groveId}",
                arguments = listOf(navArgument("groveId") { type = NavType.IntType })
            ) { backStackEntry ->
                val groveId = backStackEntry.arguments?.getInt("groveId") ?: 1
                GroveDetailScreen(
                    groveId = groveId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Scan.route) {
                SpeciesScanScreen(viewModel = viewModel)
            }
            composable(Screen.Legends.route) {
                MythLegendScreen()
            }
            composable(Screen.Alert.route) {
                ConservationAlertScreen(viewModel = viewModel)
            }
        }
    }
}
