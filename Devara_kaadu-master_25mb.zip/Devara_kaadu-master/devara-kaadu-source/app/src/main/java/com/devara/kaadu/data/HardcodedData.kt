package com.devara.kaadu.data

data class Grove(
    val id: Int,
    val nameKannada: String,
    val nameEnglish: String,
    val groveType: String,
    val district: String,
    val deity: String,
    val tagline: String,
    val latitude: Double,
    val longitude: Double,
    val legend: String,
    val speciesCount: Int,
    val endemicPlants: Int,
    val waterBodies: Int,
    val climateRole: String,
    val speciesFoundIds: List<Int>
)

data class Species(
    val id: Int,
    val commonName: String,
    val scientificName: String,
    val kannadaName: String,
    val conservationStatus: String,
    val foundInGrove: String,
    val traditionalUse: String,
    val ecologicalRole: String
)

object HardcodedData {

    val groves = listOf(
        Grove(
            id = 1,
            nameKannada = "ಕೊಡಚಾದ್ರಿ ಕಾವು",
            nameEnglish = "Kodachadri Kaavu",
            groveType = "Kaavu",
            district = "Shimoga",
            deity = "Mookambika Devi",
            tagline = "Where the goddess watches over ancient canopies",
            latitude = 13.6172,
            longitude = 74.8782,
            legend = "Mookambika Devi is said to have defeated the demon Kaumasura on this sacred peak. The forest surrounding the temple has never been touched by an axe — locals believe any tree felled here brings divine wrath. Generations of priests have maintained the grove, and hunters who ventured in for prey returned empty-handed, convinced the goddess herself drove the animals to safety. The Kaavu is considered her living palace, and the rustling of leaves at dusk is interpreted as her whisper.",
            speciesCount = 312,
            endemicPlants = 47,
            waterBodies = 6,
            climateRole = "Acts as a watershed for the Souparnika river; the dense canopy prevents soil erosion on the Western Ghats slope and sustains year-round stream flow.",
            speciesFoundIds = listOf(1, 3, 5, 7)
        ),
        Grove(
            id = 2,
            nameKannada = "ಬಿಳಿಗಿರಿ ಬನ",
            nameEnglish = "Biligiri Bana",
            groveType = "Bana",
            district = "Chamarajanagar",
            deity = "Biligiri Rangaswamy",
            tagline = "The white rock temple surrounded by ancient biodiversity",
            latitude = 11.9869,
            longitude = 77.1606,
            legend = "Biligiri Rangaswamy — the Lord of the White Rock — is believed to be the guardian of all creatures in this hill range. The Soliga tribal community has lived alongside this grove for centuries, never felling trees within its boundaries. Legend holds that a king once ordered loggers into the Bana; all fell ill within a day and none could find the path out. The grove was spared. The Soliga perform rituals here during Rangaswamy Jatre, offering honey from wild bees that nest only in the sacred trees.",
            speciesCount = 489,
            endemicPlants = 63,
            waterBodies = 9,
            climateRole = "A critical biological corridor connecting the Eastern and Western Ghats. Regulates micro-climate for surrounding coffee and spice plantations.",
            speciesFoundIds = listOf(2, 4, 6, 8)
        ),
        Grove(
            id = 3,
            nameKannada = "ಕುದುರೆಮುಖ ದೇವರಕಾಡು",
            nameEnglish = "Kudremukh Devarakadu",
            groveType = "Devarakadu",
            district = "Chikkamagaluru",
            deity = "Bhoomi Devi",
            tagline = "Earth Goddess's domain of shola grasslands and mist",
            latitude = 13.1700,
            longitude = 75.2400,
            legend = "Bhoomi Devi — the Earth Goddess — is said to sleep beneath the roots of the oldest trees in Kudremukh. When the soil is healthy, she breathes deeply and rains follow. Villagers recount that during the drought of 1972, priests performed a puja within the Devarakadu, and rain fell within three days. No cattle are allowed to graze here — the land belongs entirely to Bhoomi Devi. Children are told that the shola grass marks the goddess's hair, and the mist that covers the peaks each morning is her breath.",
            speciesCount = 267,
            endemicPlants = 41,
            waterBodies = 12,
            climateRole = "Source of three major rivers: Bhadra, Tunga, and Vedavathi. The shola-grassland mosaic stores enormous amounts of water, releasing it slowly through the dry season.",
            speciesFoundIds = listOf(1, 4, 7, 3)
        ),
        Grove(
            id = 4,
            nameKannada = "ಮೇಲುಕೋಟೆ ನಂದವನ",
            nameEnglish = "Melkote Nandavana",
            groveType = "Nandavana",
            district = "Mandya",
            deity = "Cheluvanarayana Swamy",
            tagline = "Vishnu's garden where pilgrims and parrots share the path",
            latitude = 12.6600,
            longitude = 76.6500,
            legend = "Cheluvanarayana Swamy — the Beautiful Lord Narayana — is said to have descended here to rest after a celestial journey. The Nandavana was planted by his devotees as a garden worthy of a god. Every plant in the grove has a Sanskrit name in the temple records. Parrots nesting in the old fig trees are considered sacred messengers; harming one is believed to invite seven generations of misfortune. During Vairamudi festival, thousands of pilgrims circumambulate the grove but touch nothing — the flowers bloom, the priest said, because the Lord smells them each morning.",
            speciesCount = 184,
            endemicPlants = 22,
            waterBodies = 3,
            climateRole = "Serves as an urban green lung for the Melkote hill town. Provides habitat for endemic bird species and prevents runoff into the temple tank.",
            speciesFoundIds = listOf(2, 5, 4, 6)
        ),
        Grove(
            id = 5,
            nameKannada = "ಅಗುಂಬೆ ಪವಿತ್ರವನ",
            nameEnglish = "Agumbe Pavitravana",
            groveType = "Pavitravana",
            district = "Shivamogga",
            deity = "Varuna (Rain God)",
            tagline = "Where the rain god's tears feed the Malnad jungles",
            latitude = 13.5100,
            longitude = 75.0900,
            legend = "Agumbe receives the second-highest rainfall in India, and the villagers say it is because Varuna, the Rain God, made it his home after humans began forgetting his name. The Pavitravana is never entered during the monsoon — it belongs entirely to Varuna then. Ancient lore holds that a merchant once built a house on the grove's edge and his home was struck by lightning three times. He dismantled it and planted three trees in apology. Herpetologists later discovered the grove holds the densest population of King Cobras in Asia — animals Varuna is said to ride.",
            speciesCount = 398,
            endemicPlants = 58,
            waterBodies = 15,
            climateRole = "Receives over 7500mm of annual rainfall. The intact canopy intercepts rain and releases it slowly, feeding streams that supply drinking water to five downstream villages.",
            speciesFoundIds = listOf(3, 7, 8, 1)
        )
    )

    val species = listOf(
        Species(
            id = 1,
            commonName = "Nandi Tree",
            scientificName = "Lagerstroemia microcarpa",
            kannadaName = "ನಂದಿ (Nandi)",
            conservationStatus = "Endangered",
            foundInGrove = "Kodachadri Kaavu",
            traditionalUse = "🪔 Sacred to Lord Shiva; flowers offered in Shiva temples during Shivaratri. Bark used in Ayurvedic formulations for fever and inflammation. The tree is planted near temples as a living symbol of devotion.",
            ecologicalRole = "🔬 Provides high-density timber historically important to the region. Flowers are a critical nectar source for bees and butterflies in late summer. Listed as endangered due to selective logging and habitat fragmentation."
        ),
        Species(
            id = 2,
            commonName = "Indian Gooseberry",
            scientificName = "Phyllanthus emblica",
            kannadaName = "ನೆಲ್ಲಿ (Nelli)",
            conservationStatus = "Least Concern",
            foundInGrove = "Biligiri Bana",
            traditionalUse = "🪔 Called 'Amla' — the fruit of immortality in Ayurveda. Offered to the Sun God during Makar Sankranti. Used in Chyawanprash, the ancient rejuvenating tonic. The tree is worshipped during Amalaki Ekadashi.",
            ecologicalRole = "🔬 Exceptionally high in Vitamin C (600–700mg per 100g — 20x more than oranges). Fruit consumed by over 40 bird species, making it a keystone dispersal plant. Highly drought-tolerant, stabilising degraded forest edges."
        ),
        Species(
            id = 3,
            commonName = "Malabar Kino",
            scientificName = "Pterocarpus marsupium",
            kannadaName = "ಹೊನ್ನೆ (Honne)",
            conservationStatus = "Vulnerable",
            foundInGrove = "Kudremukh Devarakadu",
            traditionalUse = "🪔 The reddish resin ('kino') is used in Hindu rituals as a substitute for blood offerings. Wood used to carve deity idols in some traditions. Prescribed in Unani medicine for treating diabetes for over 2000 years.",
            ecologicalRole = "🔬 Contains pterostilbene and epicatechin — scientifically validated anti-diabetic compounds that inspired modern drug research. A nitrogen-fixing tree that enriches soil. Now vulnerable due to over-harvesting of its medicinal bark."
        ),
        Species(
            id = 4,
            commonName = "Sacred Fig",
            scientificName = "Ficus religiosa",
            kannadaName = "ಅಶ್ವತ್ಥ (Ashwatha)",
            conservationStatus = "Least Concern",
            foundInGrove = "Melkote Nandavana",
            traditionalUse = "🪔 The holiest tree in Hindu, Buddhist, and Jain traditions. Siddhartha Gautama attained enlightenment under a Peepal. Circumambulating the tree on Saturdays is believed to remove ancestral curses. No one cuts its branches.",
            ecologicalRole = "🔬 One of the few trees that releases oxygen at night via CAM-like metabolism, improving local air quality around temples. Hosts over 50 fig wasp species in a unique co-evolutionary relationship. Figs feed birds, bats, and primates year-round."
        ),
        Species(
            id = 5,
            commonName = "Flame of Forest",
            scientificName = "Butea monosperma",
            kannadaName = "ಮುತ್ತುಗ (Muttuga)",
            conservationStatus = "Least Concern",
            foundInGrove = "Melkote Nandavana",
            traditionalUse = "🪔 The vivid orange flowers are used in Holi celebrations across India. Associated with Agni (fire god) — flowers offered in fire rituals. Lac insects cultivated on branches for natural dye. Bark cloth used in ancient Vedic ceremonies.",
            ecologicalRole = "🔬 A pioneer species that colonises degraded land and restores soil structure. Flowers bloom in February–March and are the primary nectar source for sun-birds during dry months. Leaf litter significantly improves soil nitrogen content."
        ),
        Species(
            id = 6,
            commonName = "Red Sanders",
            scientificName = "Pterocarpus santalinus",
            kannadaName = "ರಕ್ತಚಂದನ (Raktachandana)",
            conservationStatus = "Endangered",
            foundInGrove = "Biligiri Bana",
            traditionalUse = "🪔 The deep red heartwood is used in temple idols, ritual paste ('rakta chandan tilak'), and Ayurvedic preparations for skin disorders. Considered one of the most sacred woods — used in deity installation rituals. Mentioned in ancient texts as a gift worthy of gods.",
            ecologicalRole = "🔬 Listed in CITES Appendix II due to severe over-exploitation for international timber trade. Endemic to the Eastern Ghats' scrub forests. Extremely slow-growing; a mature tree is 200+ years old. Critical for soil conservation on rocky terrain."
        ),
        Species(
            id = 7,
            commonName = "Wild Turmeric",
            scientificName = "Curcuma aromatica",
            kannadaName = "ಕಾಡು ಅರಿಸಿಣ (Kadu Arishina)",
            conservationStatus = "Vulnerable",
            foundInGrove = "Agumbe Pavitravana",
            traditionalUse = "🪔 Used in sacred rituals — turmeric paste is applied to idols during consecration. Brides are anointed with wild turmeric in traditional Haldi ceremonies. Believed to purify spaces; spread on thresholds during festivals to ward off evil.",
            ecologicalRole = "🔬 Contains higher concentrations of curcuminoids than cultivated turmeric, with proven antifungal and antimicrobial properties. Pollinated exclusively by specific native bee species, making it an indicator of pollinator health. Vulnerable due to over-collection from wild habitats."
        ),
        Species(
            id = 8,
            commonName = "Indian Orchid",
            scientificName = "Vanda tessellata",
            kannadaName = "ವಂದಾ (Vanda)",
            conservationStatus = "Endangered",
            foundInGrove = "Agumbe Pavitravana",
            traditionalUse = "🪔 Used in tantric rituals as a sacred offering. The flower garlands are used to adorn deity idols during special pujas. In folk medicine, the paste of roots is applied to treat joint pain. Considered an auspicious plant whose presence indicates a healthy sacred grove.",
            ecologicalRole = "🔬 An epiphytic orchid that grows on tree bark without parasitising the host — an indicator of exceptional air quality and forest health. Endangered due to habitat loss and illegal collection for the ornamental plant trade. Pollinated by specific native carpenter bees."
        )
    )

    val groveTypeColors = mapOf(
        "Kaavu" to 0xFF2D6A4F,
        "Bana" to 0xFF1B4332,
        "Devarakadu" to 0xFF40916C,
        "Nandavana" to 0xFFD4A017,
        "Pavitravana" to 0xFF52B788
    )

    val sacredFacts = listOf(
        "The Sacred Fig (Ashwatha) releases oxygen at night — one reason ancient sages chose to meditate beneath it.",
        "Karnataka has over 1,424 documented sacred groves. They cover less than 1% of land but host over 20% of the state's plant diversity.",
        "Red Sanders trees take 200+ years to mature. Each one felled is irreplaceable within a human lifetime.",
        "Wild Turmeric found in sacred groves contains 3x more curcuminoids than cultivated varieties.",
        "The Soliga community has protected Biligiri Bana for over 400 years — making them among India's oldest conservation practitioners.",
        "Agumbe receives 7500mm of rain annually. Its Pavitravana feeds five rivers without a single dam.",
        "The Indian Orchid only grows where air quality is exceptional — its presence is nature's certificate of grove health.",
        "Malabar Kino's anti-diabetic properties were known in Ayurveda 2000 years before modern science validated them.",
        "Sacred groves in Karnataka store an estimated 2.3 million tonnes of carbon — equivalent to removing 500,000 cars for a year.",
        "The Nandi Tree is found only in 12 locations globally. All surviving populations are inside sacred groves."
    )
}
