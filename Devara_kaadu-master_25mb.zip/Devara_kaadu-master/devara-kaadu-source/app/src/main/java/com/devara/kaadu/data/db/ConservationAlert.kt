package com.devara.kaadu.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conservation_alerts")
data class ConservationAlert(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val groveName: String,
    val threatType: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long = System.currentTimeMillis()
)
