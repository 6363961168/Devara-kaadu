package com.devara.kaadu.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.devara.kaadu.data.HardcodedData
import com.devara.kaadu.data.db.AppDatabase
import com.devara.kaadu.data.db.ConservationAlert
import com.devara.kaadu.data.db.SpeciesSighting
import com.devara.kaadu.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    val allSightings: StateFlow<List<SpeciesSighting>>
    val allAlerts: StateFlow<List<ConservationAlert>>

    // Simulated GPS location (Kodachadri area)
    val mockLatitude = 13.6172
    val mockLongitude = 74.8782

    val todaysFact: String = HardcodedData.sacredFacts.random()

    private val _scanResult = MutableStateFlow<com.devara.kaadu.data.Species?>(null)
    val scanResult: StateFlow<com.devara.kaadu.data.Species?> = _scanResult

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    init {
        val db = AppDatabase.getDatabase(application)
        repository = AppRepository(db)

        allSightings = repository.allSightings.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allAlerts = repository.allAlerts.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    fun simulateScan() {
        viewModelScope.launch {
            _isScanning.value = true
            _scanResult.value = null
            kotlinx.coroutines.delay(2000)
            _scanResult.value = HardcodedData.species.random()
            _isScanning.value = false
        }
    }

    fun addSighting(speciesName: String, groveName: String) {
        viewModelScope.launch {
            repository.addSighting(
                SpeciesSighting(
                    speciesName = speciesName,
                    groveName = groveName
                )
            )
        }
    }

    fun submitAlert(groveName: String, threatType: String, description: String) {
        viewModelScope.launch {
            repository.addAlert(
                ConservationAlert(
                    groveName = groveName,
                    threatType = threatType,
                    description = description,
                    latitude = mockLatitude,
                    longitude = mockLongitude
                )
            )
        }
    }

    fun isNearGrove(grove: com.devara.kaadu.data.Grove): Boolean {
        return kotlin.math.abs(grove.latitude - mockLatitude) < 0.05 &&
               kotlin.math.abs(grove.longitude - mockLongitude) < 0.05
    }
}
