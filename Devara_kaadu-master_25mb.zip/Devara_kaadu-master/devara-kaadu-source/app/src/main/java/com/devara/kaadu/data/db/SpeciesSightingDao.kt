package com.devara.kaadu.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SpeciesSightingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(sighting: SpeciesSighting)

    @Query("SELECT * FROM species_sightings ORDER BY timestamp DESC")
    fun getAll(): Flow<List<SpeciesSighting>>

    @Query("SELECT * FROM species_sightings WHERE groveName = :groveName ORDER BY timestamp DESC")
    fun getByGrove(groveName: String): Flow<List<SpeciesSighting>>
}
