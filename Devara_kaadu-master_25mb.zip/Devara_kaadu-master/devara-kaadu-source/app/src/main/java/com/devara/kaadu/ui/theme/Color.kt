package com.devara.kaadu.ui.theme

import androidx.compose.ui.graphics.Color

val Parchment = Color(0xFFF5F0E8)
val PrimaryGreen = Color(0xFF2D6A4F)
val AccentGold = Color(0xFFD4A017)
val BarkBrown = Color(0xFF3B2F2F)
val PaleLeafGreen = Color(0xFFEAF4EA)
val DeepGreen = Color(0xFF1B4332)
val LightGold = Color(0xFFF5D080)
val DangerRed = Color(0xFFC0392B)
val EndangeredRed = Color(0xFFE74C3C)
val VulnerableOrange = Color(0xFFE67E22)
val LeastConcernGreen = Color(0xFF27AE60)
