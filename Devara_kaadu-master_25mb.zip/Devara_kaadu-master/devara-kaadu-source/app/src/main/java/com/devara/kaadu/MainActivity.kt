package com.devara.kaadu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.devara.kaadu.ui.navigation.DevaraKaaduNavGraph
import com.devara.kaadu.ui.theme.DevaraKaaduTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            DevaraKaaduTheme {
                DevaraKaaduNavGraph()
            }
        }
    }
}
