# 🌿 Devara-Kaadu — Sacred Grove Sentinel
 
> *"Where Faith Protects Nature"*
## 🌳 About the Project
 
**Devara-Kaadu** (ದೇವರ ಕಾಡು) — meaning *"Forest of the Divine"* in Kannada — is an Android application that acts as a **Sacred Grove Sentinel** for the ancient forest patches of Karnataka, India.
 
These sacred groves, protected for centuries by local deities and community faith, are among the last surviving pockets of undisturbed biodiversity in South India. This app bridges the gap between **traditional ecological knowledge** and **modern conservation science**, turning every user into a **Guardian of the Green Temple**.

---
 
## 🚨 The Problem We Solve
 
**Devara Kaadu** (Sacred Groves) are ancient forest patches traditionally protected by local deities. They serve as:
 
- 🌱 **Biodiversity hotspots** for rare and endemic flora/fauna
- 💧 **Natural water rechargers** feeding local wells and streams
- 🌡️ **Micro-climate coolers** buffering extreme temperatures
- 📜 **Living libraries** of Traditional Ecological Knowledge (TEK)
**However**, these irreplaceable ecosystems face a silent crisis:
- Youth perceive them only as **"Religious Spots"**, not **"Biological Treasures"**
- Encroachment and waste dumping are accelerating
- The oral ecological history is being forgotten with each passing generation
- Conservation organizations lack community-level surveillance data
**Devara-Kaadu** solves this by making the scientific and spiritual story of each grove accessible, engaging, and actionable for the local community.
 
---
 
## ✨ Features
 
### 🗺️ Grove Directory
A curated directory of Sacred Groves across Karnataka districts.
- Browse by grove type: **Kaavu, Bana, Devarakadu, Nandavana, Pavitravana**
- GPS-based **proximity unlock** — get special content when you're physically near a grove
- Each grove entry includes district, presiding deity, and biodiversity highlights
### 📖 Divine Legend & Scientific Facts
Every grove has **two clearly separated content layers**:
| 🪔 Traditional Belief | 🔬 Scientific Fact |
|---|---|
| Deity stories and folk legends | Biodiversity census data |
| Ritual significance of species | Ecological role and conservation status |
| Community taboos protecting trees | Climate and watershed functions |
 
### 🌿 Species Scanner (Simulated AI)
- Simulates plant/herb identification using an on-screen camera overlay
- Returns one of **8+ native species** from the grove database
- Shows **Conservation Status** (Endangered / Vulnerable / Least Concern)
- Displays both **Traditional Use** and **Ecological Role** for each species
- Log your sighting directly to the local grove record
### 📜 Myth & Legend Gallery
- Full-page scroll of deity stories, one per grove
- Parchment-style UI with gold accents, serif fonts, and expandable legend cards
### 🚨 Conservation Alert System
- Report threats: Waste Dumping, Tree Cutting, Encroachment, Poaching
- Auto-captured GPS coordinates with each report
- All alerts saved locally and displayed in a Recent Alerts feed
---

## 🛠️ Tech Stack
 
| Layer | Technology |
|---|---|
| **Language** | Kotlin |
| **UI Framework** | Jetpack Compose |
| **Architecture** | MVVM (ViewModel + StateFlow) |
| **Navigation** | Jetpack Navigation Compose |
| **Local Database** | Room (SQLite) |
| **Location** | Google Fused Location Provider API |
| **Async** | Kotlin Coroutines + Flow |
| **DI** | Manual (ViewModel Factory) |
| **Build System** | Gradle (Kotlin DSL) |
| **Min SDK** | API 24 (Android 7.0 Nougat) |
| **Target SDK** | API 34 (Android 14) |
 
---
### Prerequisites
 
- Android Studio **Hedgehog** (2023.1.1) or later
- JDK **17**
- Android device or emulator running **API 24+**
- Internet connection (for initial Gradle sync)

## 🌍 Impact Goals
 
| Goal | How the App Contributes |
|---|---|
| 🌿 **Biodiversity Conservation** | Community faith + scientific awareness = stronger local protection |
| 🌡️ **Climate Resilience** | Educates users on sacred groves as micro-climate coolers |
| 💧 **Water Security** | Highlights groves as natural water recharge zones |
| 📚 **Cultural Heritage** | Digitally preserves Traditional Ecological Knowledge (TEK) |
| 🚨 **Real-time Surveillance** | Conservation Alerts create a community reporting network |
 
---
